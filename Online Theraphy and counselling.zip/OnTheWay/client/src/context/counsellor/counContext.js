import { createContext } from "react";

// Create context
const counContext = createContext();

export default counContext;
