import { createContext } from "react";

// Create context
const adminContext = createContext();

export default adminContext;
